from django.apps import AppConfig


class WorkflowEngineConfig(AppConfig):
    name = 'workflow_engine'
